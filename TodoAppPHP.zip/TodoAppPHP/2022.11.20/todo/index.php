<?php
require "Todo.php";

$todo=new Todo(1,1,"asd",1);



echo "todoID: ".$todo->getTodoId()."<p>";
echo "todo user: ".$todo->getUserID()."<p>";
echo "todoDescription: ".$todo->getDescription()."<p>";
echo "todo category: ".$todo->getCategory()."<p>";
echo "todo getCompleted: ".$todo->getCompleted()."<p>";
?>