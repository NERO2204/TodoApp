<?php
class Todo
{
    private $id;
    private $user;
    private $description;
    private $category;
    private $compeleted;
    function __construct($id,$user,$description,$category)
    {
        $this->id=$id;
        $this->user=$user;
        $this->description=$description;
        $this->category=$category;
        $this->completed=0;
    }
    function getTodoId()
    {
        return $this->id;
    }
    function getUserID()
    {
        return $this->user;
    }
    function getDescription()
    {   
        return $this->description;
    }
    function getCategory()
    {
        return $this->category;
    }
    function getCompleted()
    {
        return $this->completed;
    }
    
}
?>