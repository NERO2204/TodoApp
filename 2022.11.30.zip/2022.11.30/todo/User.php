<?php
require "Todo.php";
class User
{
    private $userId;
    private $name;
    private $todos;
    function __construct($userId,$name)
    {
        $this->userId=$userId;
        $this->name=$name;
        $this->todos=array();

    }
    function getTodoList()
    {
        
        return $this->todos;
    }



    public static function getAll($conn)
    {
        $sql = "SELECT *
                FROM todo ";

        $results = $conn->query($sql);

        return $results->fetchAll(PDO::FETCH_ASSOC);
    }
    static function addTodo($conn,$todo)
    {
        $todoDesc=$todo->getDescription();

        
        $sql = "INSERT INTO `todo`(`user`, `description`, `category`, `completed`) VALUES ('1',:descript,'1','0')";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':descript',$todoDesc, PDO::PARAM_STR);
        $stmt->execute();
      
   
    }
    static function completeTodo($conn,$todo)
    {
      
        $sql = " UPDATE `todo` SET `completed`=1 WHERE id=:id";
        $todoID=$todo->getTodoId();
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':id',$todoID, PDO::PARAM_INT);
        $stmt->execute();
      
       

    }
    static function deleteTodo($conn,$todo)
    {
        $sql = "DELETE FROM `todo` WHERE id=:id";
        $todoID=$todo->getTodoId();
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':id',$todoID, PDO::PARAM_INT);
        $stmt->execute();
        

    }
    function getUserId()
    {
        return $this->userId;
    }
    function getUserName()
    {
        return $this->name;
    }
    
    public static function todoGetByID($conn, $id, $columns = '*')
     {
         $sql = "SELECT $columns
                 FROM todo
                 WHERE id = :id";
 
         $stmt = $conn->prepare($sql);
         $stmt->bindValue(':id', $id, PDO::PARAM_INT);
 
         $stmt->setFetchMode(PDO::FETCH_CLASS,'Todo');
 
         if ($stmt->execute()) {
 
             return $stmt->fetch();
 
         }
     }
 
   


}









?>