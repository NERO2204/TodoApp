<?php
require "User.php";
require "Database.php";
$db = new Database();
$conn = $db->getConn();


if (isset($_GET['id']))
{

    $todo=User::todoGetByID($conn,$_GET['id']);
    echo $todo->getTodoId();

    
}



