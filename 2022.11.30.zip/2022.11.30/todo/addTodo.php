<html>
<body>

<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
 
  <input type="submit">
</form>

<?php

require "User.php";
require "Database.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
  $db = new Database();
  $conn = $db->getConn();
  $desc = $_POST['desc'];
  $todo=new Todo();
  $todo->setTodoDatas(1,$desc,1,0);
  User::addTodo($conn,$todo);
}
?>

</body>
</html>