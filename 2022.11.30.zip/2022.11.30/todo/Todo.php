<?php
class Todo
{
    private $id;
    private $user;
    private $description;
    private $category;
    private $completed;
    private $shortDesc;
    function setTodoDatas($user,$description,$category,$completed,$shortDesc)
    {
        
        $this->user=$user;
        $this->description=$description;
        $this->category=$category;
        $this->completed=$completed;
        $this->shortDesc=$shortDesc;
    }
   
    function getTodoId()
    {
        return $this->id;
    }
    function getUserID()
    {
        return $this->user;
    }
    function getDescription()
    {   
        return $this->description;
    }
    function getCategory()
    {
        return $this->category;
    }
    function getCompleted()
    {
        return $this->completed;
    }
    function setTodoComplete()
    {
        $this->completed=1;
    }
    function getShortDesc()
    {
        return $this->shortDesc;

    }
 
    
    
}
?>