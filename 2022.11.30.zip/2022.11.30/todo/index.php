

<?php
require "Database.php";

require "User.php";
$db = new Database();
$conn = $db->getConn();

$todos=User::getAll($conn);
foreach($todos as $todo)
{
  
    ?>
    
    <a href="singleTodo.php?id=<?=$todo['id']; ?>"><?=$todo['description'];?></a><p>
    <?php
}





?>