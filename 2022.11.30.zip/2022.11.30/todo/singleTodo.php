<?php

require "User.php";
require "Database.php";
$db = new Database();
$conn = $db->getConn();
$todoTest;
   
if (isset($_GET['id']))
{

    $todo=User::todoGetByID($conn,$_GET['id']);
    

    
}


if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    User::deleteTodo($conn,$todo);
   
    
}





 







?>

<html>
<body>
    <h1><?php echo $todo->getShortDesc();?></h1>
    <h2><?php echo $todo->getDescription();?></h2>

<form method="post" >
 
  <button>Complete</button>
</form>
